#!/usr/local/bin/python3.6

import cv2, os
import matplotlib.pyplot as plt 

def imlist(path):
    """
    Cette fonction permet de renvoyer les noms des images dans le chemin du du repertoire fourni comme argument
    """
    return [os.path.join(path, f) for f in os.listdir(path)]

def imshow(im_title, im):
    ''' Affichage des images'''
    plt.figure()  
    plt.title(im_title)
    plt.axis("off")
    if len(im.shape) == 2:
        plt.imshow(im, cmap = "blue")
    else:
        im_display = cv2.cvtColor(im, cv2.COLOR_RGB2BGR)
        plt.imshow(im_display)
    plt.show()

def imreads(path):
    '''
     Renvoit les resultats des images lu dans un dossier
    '''
    images_path = imlist("/home/bikz05/Desktop/back_projection")
    images = []
    for image_path in images_path:
        images.append(cv2.imread(image_path, cv2.CV_LOAD_IMAGE_COLOR))
    return images

def show(image, name="Image"):
    '''
    Routine d'affichage des images
    '''
    cv2.namedWindow(name, cv2.WINDOW_NORMAL)
    cv2.imshow(name, image)
    cv2.waitKey(0)
